<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

use App\Http\Controllers\MailerController ;

class WABAMessageTemplateController extends Controller
{

  public function newUserMessage($phone, $name)
  {
      $message = "Hi ".$name.", \nit seems its your first time here. We are indeed glad to have you onboard and we hope you will have a wonderful experience.";
      return $message;
  }

  public function responseToGreeting()
  {
    $message = "Hi, Thanks for contacting us. Kindly respond with a number associated with the service you need.\n";
    $message .= "1. *Laundry Service*\n";
    $message .= "2. *Track Laundry Order*\n";
    $message .= "3. *Internet Data*\n";
    $message .= "4. *MTN SME Data*\n";
    $message .= "5. *Airtime (VTU)*\n";
    $message .= "6. *Print Airtime*\n";
    $message .= "7. *Electricity Bills*\n";
    $message .= "8. *Topup Earn Wallet Balance*\n";
    $message .= "9. *Open Topup Earn Account*\n";
    $message .= "10. *Shortcut keys*\n";
      return $message;
  }

  public function shortcutKeys()
  {
    $message = "You can use the short keys below to request for the list services.";
    $message .= "\nlaundry - *Laundry Service*";
    $message .= "\ntrack - *Track Laundry Order*";
    $message .= "\ndata - *Internet Data*";
    $message .= "\nsme - *MTN SME Data*";
    $message .= "\nairtime - *Airtime (VTU)*";
    $message .= "\nprint - *Print Airtime*";
    $message .= "\npower *Electricity Bills*";
    $message .= "\ntopupwallet *Topup Earn Wallet Balance*";
    $message .= "\nshortcut - *Shortcut keys*";
      return $message;
  }

  public function noTopupearnAccount()
  {
      $message = "Sorry, no top up earn account is linked to this number. Kindly signup or request for your phone number update.";
      return $message;
  }

}
