<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

use App\Http\Controllers\MailerController;
use App\Http\Controllers\WABAMessageTemplateController;

class WhatsAppCloudController extends Controller
{
  private $version = "v13.0";
  private $messagingProduct = "whatsapp";
  private $recipientType = "individual";
  private $businessId = "432041555402309";
  private $phoneNumberId = "104470072401342";
  private $accessToken = "EAAWLn07CoDgBAO8lbxZBTHZCjBp8pZALXPWFonMGoTt0d1Rjs1HsWxHV2frve3zvrDX3FoAEDufhw9YLhFIzB3qw87qy9MqOiVfj2JAPr751rHh8aXHEabd8g1DFEoHBE6ZAdW2bgxVIJVAruOePodrfl5WAqV3y8IjUcwnhV26anaRHbJxHGZCCDNzQZCqs3fNuySY9Yk7QZDZD";
  private $wABAId = "103383822512018"; //Whatsapp business account ID

  public function sendMail($subject, $to, $from, $msg)
  {
      $mailer = new MailerController;
      $mailer->sendMail($subject, $to, $msg);
  }

  public function SendTextMessage($text, $phone, $withUrl)
  {
      $data = [
          "messaging_product" => $this->messagingProduct,
          'recipient_type' => $this->recipientType,
          'to' => $phone,
          'type' => 'text',
          'text' => array(
        'preview_url' => $withUrl,
        'body' => $text
        )
      ];

$url = "https://graph.facebook.com/".$this->version."/".$this->phoneNumberId."/messages";
      // Initializes a new cURL session
      $curl = curl_init($url);
      // Set the CURLOPT_RETURNTRANSFER option to true
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
      // Set the CURLOPT_POST option to true for POST request
      curl_setopt($curl, CURLOPT_POST, true);
      // Set the request data as JSON using json_encode function
      curl_setopt($curl, CURLOPT_POSTFIELDS,  json_encode($data));
      // Set custom headers for RapidAPI Auth and Content-Type header
      curl_setopt($curl, CURLOPT_HTTPHEADER, [
          'Content-Type: application/json',
          'Authorization: Bearer '.$accessToken
        ]);
      // Execute cURL request with all previous settings
      $response = curl_exec($curl);
      $json_obj   = json_decode($response);
                    //$response = $json_obj->status;
      // Close cURL session
      curl_close($curl);

      //return response()->json(['status' => 1, 'message' => $json_obj], 200);

      if($json_obj == null){
          return false;
      }

      else if($json_obj->error && $json_obj->error != null){
          return false;
      }
      else
      {

        DB::insert('insert into whatsapp_cloud_messages (
            phone, message, message_id, message_type
            )
        values (?, ?, ?, ?)', [
            $phone, $text, $json_obj->messages->id, "outbound"
        ]);

        return true
      }
  }

  public function SendTemplateMessage($text, $phone, $template_name)
  {
      $data = [
          "messaging_product" => $this->messagingProduct,
          'recipient_type' => $this->recipientType,
          'to' => $phone,
          'type' => 'template',
          'template' => array(
        'name' => $template_name,
        'language' => array(
           'code' => 'en_US'
        )
        )
      ];

$url = "https://graph.facebook.com/".$this->version."/".$this->phoneNumberId."/messages";
      // Initializes a new cURL session
      $curl = curl_init($url);
      // Set the CURLOPT_RETURNTRANSFER option to true
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
      // Set the CURLOPT_POST option to true for POST request
      curl_setopt($curl, CURLOPT_POST, true);
      // Set the request data as JSON using json_encode function
      curl_setopt($curl, CURLOPT_POSTFIELDS,  json_encode($data));
      // Set custom headers for RapidAPI Auth and Content-Type header
      curl_setopt($curl, CURLOPT_HTTPHEADER, [
          'Content-Type: application/json',
          'Authorization: Bearer '.$accessToken
        ]);
      // Execute cURL request with all previous settings
      $response = curl_exec($curl);
      $json_obj   = json_decode($response);
                    //$response = $json_obj->status;
      // Close cURL session
      curl_close($curl);


      if($json_obj == null){
          return false;
      }

      else if($json_obj->error && $json_obj->error != null){
          return false;
      }
      else
      {

        DB::insert('insert into whatsapp_cloud_messages (
            phone, message, message_id, message_type
            )
        values (?, ?, ?, ?)', [
            $phone, $text, $json_obj->messages->id, "outbound"
        ]);

        return true
      }
  }

  public function MessagesWebhook(Request $request)
  {

$apiSecret = 'r4dtre#sfdgh';

$requestMethod = $_SERVER['REQUEST_METHOD'] ?? '';
$receivedHmac = $_SERVER['HTTP_X_CS_SIGNATURE'] ?? '';
$timestamp = $_SERVER['HTTP_X_CS_TIMESTAMP'] ?? '';
$url = $_SERVER['REQUEST_URI'];
$body = file_get_contents('php://input');

$data = $requestMethod . $url . $timestamp . $body;
$hmac = hash_hmac('sha256', $data, $apiSecret);

$isValid = hash_equals($hmac, $receivedHmac);

if(!$isValid)
{

}
else
{
  $messagesRes = new WABAMessageTemplateController;

  $validator = Validator::make($request->all(), [
      'object' => 'required|string',
      'entry' => 'nullable|json'
  ]);

  if($request->entry)
  {

    $messageType = "";
    $message_id = "";
    $message = "";
    $messageSent = "";
    $phone = "";
    $name = "";
    $message_type = "";

    $whatsapp_user = DB::table('whatsapp_cloud_users')
    ->Where('phone', $phone)
    ->first();

    //last response from us
        $last_message_out = DB::table('whatsapp_cloud_messages')
        ->Where('phone', $phone)
        ->Where('message_type', 'outbound')
        ->first();

        //last response from user
            $last_message_in = DB::table('whatsapp_cloud_messages')
            ->Where('phone', $phone)
            ->Where('message_type', 'inbound')
            ->first();

    if($request->entry["changes"]["statuses"]["status"])
    {
      $messageType = "outbound";
    }
    if($request->entry["changes"]["messages"]["from"])
    {
      $messageType = "inbound";
    }

if($messageType == "inbound")
{
  $message_id = $request->entry["changes"]["messages"]["id"];
  $message = $request->entry["changes"]["messages"]["text"]["body"];
  $phone = $request->entry["changes"]["messages"]["from"];
  $name = $request->entry["contacts"]["profile"]["name"];
  $message_type = $messageType;

  //insert new user
          if(!$whatsapp_user)
          {

            $this->SendTextMessage($messagesRes->newUserMessage($phone, $name), $phone, false);

            DB::insert('insert into whatsapp_cloud_users (
                phone, name
                )
            values (?, ?)', [
                $phone, $name
            ]);
          }
          if(trim(strtolower($message)) == "hello" || trim(strtolower($message)) == "hi")
          {
            $this->SendTextMessage($messagesRes->responseToGreeting(), $phone, false);
          }

          if(trim(strtolower($message)) == "shortcut")
          {
            $this->SendTextMessage($messagesRes->shortcutKeys(), $phone, false);
          }

          //save message in db
          DB::insert('insert into whatsapp_cloud_messages (
              phone, name, message, message_id, message_type
              )
          values (?, ?, ?, ?, ?)', [
              $phone, $name, $message, $message_id, $message_type
          ]);

return response()->json(['status' => 1, 'message' => "Task Completed"], 200)

}


else if($messageType == "outbound")
{

  //save message in db if sent only
  if($request->entry["changes"]["statuses"]["status"] == "sent")
{

  $message_id = $request->entry["changes"]["statuses"]["id"];

  DB::update('update whatsapp_cloud_messages set message_status = ?
    where message_id = ?',["sent", $message_id]);

}
return response()->json(['status' => 1, 'message' => "Task Completed"], 200)
}
else
{
return response()->json(['status' => 0, 'message' => "Failed"], 401)  
}

  }

}

  }


}
